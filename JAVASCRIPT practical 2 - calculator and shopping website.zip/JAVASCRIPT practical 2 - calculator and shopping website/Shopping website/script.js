let cart = [];
let total = 0;

function addToCart(name, price) {
  let existing = cart.find(item => item.name === name);
  if (existing) {
    existing.qty++;
  } else {
    cart.push({ name, price, qty: 1 });
  }
  updateCart();
}

function updateCart() {
  const cartList = document.getElementById('cart-items');
  const cartTotal = document.getElementById('cart-total');
  
  cartList.innerHTML = '';
  total = 0;

  cart.forEach((item, index) => {
    total += item.price * item.qty;

    const li = document.createElement('li');
    li.innerHTML = `
      ${item.name} x${item.qty} - ₹${item.price * item.qty}
      <button class="remove-btn" onclick="removeFromCart(${index})">✖</button>
    `;
    cartList.appendChild(li);
  });

  cartTotal.textContent = total;
}

function removeFromCart(index) {
  cart.splice(index, 1);
  updateCart();
}

document.getElementById('clear-cart').addEventListener('click', () => {
  cart = [];
  updateCart();
});
